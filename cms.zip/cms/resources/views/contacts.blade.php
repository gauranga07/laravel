@extends('layouts.app')

@section('content')
    Contacts
@stop