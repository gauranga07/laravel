@extends('layouts.app')

@section('content')
    Post {{$id}} {{$name}} {{$password}}
@stop