<?php $__env->startSection('content'); ?>
    Post <?php echo e($id); ?> <?php echo e($name); ?> <?php echo e($password); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/post.blade.php ENDPATH**/ ?>