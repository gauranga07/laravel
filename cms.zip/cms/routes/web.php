<?php
use App\Post;
use App\User;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    //return "Hi you";
    return view('welcome');


});

//Route::get('/about', function () {
//    return "<h1>About</h1>";
//
//
//});
//
//Route::get('/contact', function () {
//    return "<h1>Contact</h1>";
//
//
//});
//
//Route::get('/variable/{id}', function ($id) {
//    return "<h1>This value of the variable is </h1>"."<h1>$id</h1>";
//
//
//});
//
//Route::get('/variable/{id}/{name}', function ($id,$name) {
//    return "<h1>This value of the variable is </h1>"."<h1>$id</h1>"." <br> <h1>And the value of the second variable is </h1> ".$name;
//
//
//});
//
//Route::get("/admin/posts/example",array('as' => 'admin.home',function(){
//    $url = route("admin.home");
//    return "<h1>This url is".$url."</h1>";
//}));
//
//Route::get('/post/{id}','Controller2@index');
Route::resource('post','Controller2');

Route::get('contact','Controller2@contact');

Route::get('posts/{id}',"Controller2@show_post");

Route::get('posts/{id}/{name}/{password}',"Controller2@show_post_multiple_param");

#############################################################################################################
#Methods -> Insert
#hardcoded insert
Route::get('/insert', function(){
    DB::insert(
                'insert into post(title, content)values(?,?)',
                 ["this is item 2 head","this is item 1 tail"]
    );
});

#insert from url
Route::get('/insert/{value1}/{value2}', function($value1,$value2){
    DB::insert(
        'insert into post(title, content)values(?,?)',
        [$value1,$value2]
    );
});
Route::get('/insert/{id}/{value1}/{value2}', function($id,$value1,$value2){
    DB::insert(
        'insert into post(title, content)values(?,?) where id=?',
        [$value1,$value2,$id]
    );
});
#############################################################################################################
#Methods -> Read
#reads first item
Route::get('/read',function(){
    $results = DB::select('select * from post where id = ?',[1]);
    foreach($results as $post) {
        return $post->title;
    }
});

#read based on id number
Route::get('/read/{id}',function($id){
    $results = DB::select('select * from post where id = ?',[$id]);
    foreach($results as $post) {
        echo $post->title;
    }
});

#reads and shows details of post based on id number
Route::get('/read/{id}/{details}',function($id,$details){
    if($details="yes"){
    $results = DB::select('select * from post where id = ?',[$id]);

    //return $results;
    return var_dump($results);}
    else return null;
});

#############################################################################################################
#Methods -> Update
Route::get('/update',function(){

    $update = DB::update('update post set title = "Updated Title"
                          where id= ?',[1]);

    return $update;
});

Route::get('/update/{id}/{title}',function($id,$title){

    $update = DB::update('update post set title = ?
                          where id= ?',[$title,$id]);

    return $update;
});
#############################################################################################################
#Methods -> Delete
Route::get("/delete",function(){

    $deleted = DB::delete("delete from post where id = ?",[$id=1]);
    return $deleted;
});

Route::get("/delete/{id}",function($id){
    $deleted = DB::delete("delete from post where id = ?", [$id]);
    return $deleted;
});
#############################################################################################################
#Model Based data retrieval
#############################################################################################################


#Method -> Find
Route::get('/find',function(){
    $posts = Post::all();

    foreach($posts as $post){
        echo $post -> content.",<br>";
    }
    //return $posts;
});

Route::get('/find/{id}',function($id){
    $post = Post::find($id);
    return $post;
});

Route::get('/find_where/{id}',function($id){
    $posts = Post::where('id',$id)->orderBy("id","desc")->take(1)->get();
    return $posts;
});
Route::get('/find_where/{id}',function($id){
    $posts = Post::where('content',$id)->orderBy("id","desc")->take(3)->get();
    return $posts;
});

#############################################################################################################
#Method -> Insert

#Model Save
Route::get('/basic_insert/{title}/{content}',function($title,$content){

    $post = new Post;
    $post->title = $title;
    $post->content = $content;
    $post -> save();
});

Route::get('/basic_update/id',function($id){

    $post = Post::find($id);
    $post->title = 'Inserted using Eloquent (Model based)';
    $post->content = 'This is the content of the model insert';
    $post -> save();
});


#Method ->Model Create
Route::get('/model_create',function(){

    Post::create(["title"=>"Inserted using the created Method","content"=>'I overwrote fillable in the model to use this create method']);
});

#Method -> Model Update
Route::get('model_update/{id}/{title}/{content}',function($id,$title,$content){
   Post::where('id',$id)->update(['title'=>$title,'content'=>$content]);
});

#Method -> Model Delete
Route::get('/model_delete/{id}',function($id){
    $post = Post::find($id);
    $post->delete();
});

#Method -> Model Retreive
Route::get('/model_find/{id}',function($id){
    $post = Post::find($id);
    return $post;
});

#Method many records delete
Route::get('/delete2/',function(){
    Post::destroy([4,5]);
});

#issue-------------------------------------------------
Route::get('/model_soft_delete/{id}',function($id){

    $result = Post::find(4);
   // dd($result);
    //echo $result;
    $result->delete();
    });

Route::get("/user/{id}/post",function($id){
   return User::find($id)->post;
});