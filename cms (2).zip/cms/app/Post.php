<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

#assumes a table posts exists
class Post extends Model
{
  // SoftDeletes;
    protected $date = ['deleted at'];
    #redefines the table and primary key values
    protected $table = 'post';
    //protected $primaryKey = 'post_id';

    protected $fillable= [
        'title',
        'content'
    ];
    public function user(){
        return $this->belongsTo("App\User");
    }

    public function photos(){
        return $this->morphMany("App\Photo","imageable");
    }


}
