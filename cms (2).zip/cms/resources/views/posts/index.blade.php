
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Posts</title>
</head>
<body>
<table border="1">
    <tr>
        <th>Title</th>
        <th>Content</th>
        <th>User Id</th>
    </tr>
@for($i = 0; $i < count($something); $i++)
    <tr>
        <td>{{ $something[$i]->title }}</td>
        <td>{{ $something[$i]->content }}</td>
        <td>{{ $something[$i]->user_id }}</td>
    </tr>
@endfor
</table
        </body>
        </html>