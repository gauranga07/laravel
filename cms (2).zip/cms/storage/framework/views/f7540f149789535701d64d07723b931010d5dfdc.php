
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Posts</title>
</head>
<body>
<table border="1">
    <tr>
        <th>Title</th>
        <th>Content</th>
        <th>User Id</th>
    </tr>
<?php for($i = 0; $i < count($something); $i++): ?>
    <tr>
        <td><?php echo e($something[$i]->title); ?></td>
        <td><?php echo e($something[$i]->content); ?></td>
        <td><?php echo e($something[$i]->user_id); ?></td>
    </tr>
<?php endfor; ?>
</table
        </body>
        </html><?php /**PATH C:\xampp\htdocs\cms\resources\views/posts/index.blade.php ENDPATH**/ ?>